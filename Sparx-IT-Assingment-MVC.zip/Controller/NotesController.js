const Note = require('../Model/noteModel')
const mongoose = require('mongoose')

const createNote = async (req, res) => {
    try {
        const { title, content } = req.body
        const note = await Note.create({
           title,
           content,
        user : req.user.id
        })

        res.status(201).json({
            message:"Notes record created",
            data : note
        })

    } catch (err) {
        res.status(500).json({
            message: err.message
        })
    }
}

const getNotes = async (req, res) => {
    try {
        const notes = req.user.role === "admin" ? await Note.find() : await Note.find({
            user: req.user.id
        })

        if(!notes.length){
            return res.status(404).json({
                message:"No Data found"
            })
        }
        res.json(notes)

    } catch (err) {
        res.status(500).json({
            message: err.message
        })
    }
}

const getSingleNote = async (req,res)=>{
    try{
        const {id} = req.params
        const note = await Note.findById(id)

        if(!note){
            return res.status(404).json({
                message:"this Note not found"
            })
        }

        
        if(req.user.role !== "admin" && note.user.toString() !== req.user.id){
            return res.status(403).json({
                message:"Unauthorized , only valid user or admin can view his records"
            })
        }

        res.json(note)



    }catch(err){
        res.status(500).json({
            message: err.message
        })
    }
}

const updateNotes = async (req,res)=>{
    try{
        const {id} = req.params
        const note = await Note.findById(id)

        if(!note){
            return res.status(404).json({
                message:"this Note not found"
            })
        }

        if(note.user.toString() !== req.user.id){
            return res.status(403).json({
                message:"Unauthorized , only valid user can update his records"
            })
        }
      

        note.title = req.body.title || note.title
        note.content = req.body.content || note.content

        await note.save()

        res.json(note)
     
    }catch(err){
        res.status(500).json({
            message: err.message
        })
    }
}

const deleteNotes = async(req,res)=>{
    try{
        const {id} = req.params
        const note = await Note.findById(id)

        if(!note){
            return res.status(404).json({
                message:"this Note not found"
            })
        }

        if(req.user.role !== "admin" && note.user.toString() !== req.user.id){
            return res.status(403).json({
                message:"Unauthorized , only valid user or admin can delete his records"
            })
        }

        await note.deleteOne()
        res.json({
            message:'records deleted'
        })

    }catch(err){
        res.status(500).json({
            message: err.message
        })
    }
}


const shareNote = async (req, res) => {
    try {
        const { id } = req.params
        const { userId } = req.body

        if (!mongoose.Types.ObjectId.isValid(userId)) {

            return res.status(400).json({
                message: "Invalid user id"
            })
        }

        const note = await Note.findOne({ _id: id })

        if (!note) {
            return res.status(404).json({
                message: "this Note not found"
            })
        }
        if (note.user.toString() !== req.user.id) {
            return res.status(403).json({
                message: "Unauthorized , only valid user can share this records"
            })
        }

        const objectIdUser = new mongoose.Types.ObjectId(userId)
        if (!note.sharedWith.includes(objectIdUser)) {
            note.sharedWith.push(objectIdUser)
            await note.save()

        }
        res.json({
            message: "Note share successfully"
        })

    } catch (err) {
        res.status(500).json({
            message: err.message
        })
    }
}

module.exports= {createNote,getNotes,updateNotes,deleteNotes,getSingleNote,shareNote}
