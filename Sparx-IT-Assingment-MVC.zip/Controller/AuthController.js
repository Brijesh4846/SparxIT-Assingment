const User = require('../Model/userModel')
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');



const Register = async (req, res) => {
    try {
        const { name, email, password, role } = req.body
        let user = await User.findOne({ email })
        if (user) {
            return res.status(400).json({
                message: "user already exist ,try different email"
            })
        }
        const hashedPassword = await bcrypt.hash(password, 10)

        const saveData = await User.create({
            name,
            email,
            password: hashedPassword,
            role
        })

        res.status(201).json({
            data: saveData,
            message: 'user created Succesfully'
        })

    } catch (err) {
        res.status(500).json({
            message: 'server error',
            error: err.message
        })
    }
}

const Login = async (req, res) => {
    try {
        const { email, password } = req.body
        const user = await User.findOne({ email })

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({
                message: "Invalid credentials"
            })
        }

        const token = jwt.sign({
            id: user._id,
            name: user.name,
            role: user.role
        }, process.env.JWT_SECRET, { expiresIn: "2h" })

        res.status(200).json({
            token: token
        })

    } catch (err) {
        res.status(500).json({
            message: err.message
        })
    }
}



module.exports = {Register,Login}