
const mongoose = require('./config')

const noteSchema = mongoose.Schema({
    title: {
        required: true,
        type: String
    },
    content: {
        required: true,
        type: String,
    },
    user :{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },
    sharedWith:[{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User"
    }]
},
{Timestamps:true}
)

const Note = mongoose.model('Note',noteSchema);

module.exports = Note
