
const mongoose = require('./config')

const userSchema = mongoose.Schema({
    name: {
        required: true,
        type: String
    },
    email: {
        required: true,
        type: String,
        unique: true
    },
    password: {
        required: true,
        type: String
    },
    role:{
        required:true,
        enum:['user','admin'],
        default:'user',
        type:String
    }
},
{Timestamps:true}
)

const User = mongoose.model('User',userSchema);

module.exports = User


