const express = require('express');
const app = express();
require('dotenv').config()
app.use(express.json());


const UserController = require('./AuthController');
const NotesController = require('./NotesController');

const Middleware = require('./authMiddleware')


app.get('/',(req,res)=>{
    res.send({
        status:200,
        Message:'Notes home page'
    })
})


app.post('/register',UserController.Register);
app.post('/login',UserController.Login)
app.post('/create-note',Middleware.authMiddleware , NotesController.createNote)
app.get('/get-notes',Middleware.authMiddleware, NotesController.getNotes)
app.get('/get-note/:id',Middleware.authMiddleware,NotesController.getSingleNote)
app.put('/update-note/:id',Middleware.authMiddleware,NotesController.updateNotes)
app.delete('/delete-note/:id',Middleware.authMiddleware ,NotesController.deleteNotes)
app.post('/share-notes/:id',Middleware.authMiddleware,NotesController.shareNote)



app.listen(5500,()=>{
    console.log('server listen on')
})